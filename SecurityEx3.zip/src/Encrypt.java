
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.spec.GCMParameterSpec;

public class Encrypt {

    public static byte[] encrypt(String plainText, String key) throws Exception {
        byte[] clean = plainText.getBytes();
        // Generating IV.
        int ivSize = 16;
        byte[] iv = new byte[ivSize];
        SecureRandom random = new SecureRandom();
        random.nextBytes(iv);
        GCMParameterSpec GCMParameter = new GCMParameterSpec(ivSize * Byte.SIZE, iv);//kainourio mode kryptografishs  

        // Hashing key.
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        digest.update(key.getBytes("UTF-8"));//pairnei thn grammh 20 kai thn kanei update me thn 43

        byte[] keyBytes = new byte[16];
        System.arraycopy(digest.digest(), 0, keyBytes, 0, keyBytes.length);//copy to to kleidi pou dhmiourgithike sth gramh 32

        SecretKeySpec secretKeySpec = new SecretKeySpec(keyBytes, "AES");//pernei ton pinaka kai ton algorithmo pou theloume kai dhmiourgia mystikou kleidiou

        // Encrypt.
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");//Latest version GCM mode encryption is also features in a TLS RFC, and in XML encrypt 1.1 (both not final). GCM mode provides all three security features: confidentiality, integrity and authenticity of the data send se sxesh me to AES/CBC/PKCS5Padding
        cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, GCMParameter);//CMAC pio safe!
        byte[] encrypted = cipher.doFinal(clean);

        // Combine IV and encrypted part.
        byte[] encryptedIVAndText = new byte[ivSize + encrypted.length];//???
        System.arraycopy(iv, 0, encryptedIVAndText, 0, ivSize);
        System.arraycopy(encrypted, 0, encryptedIVAndText, ivSize, encrypted.length);
        return encryptedIVAndText;
    }
    private final static char[] hexArray = "0123456789ABCDEF".toCharArray();

    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }
}
